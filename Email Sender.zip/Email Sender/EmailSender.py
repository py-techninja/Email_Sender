import pyautogui as auto
from time import sleep
from random import randint

class EmailSender():
    def __init__(self):
        self.auto = auto
        self.logged_in = False
        while not self.logged_in:
            try:
                self.logged_in = bool(auto.locateOnScreen('assets/Compose.png'))
            except:
                pass   
        
    def sendMessage(self, user, message, subject=''):
        if not self.logged_in:
            return False
        
        sleep(randint(1,3))

        while True:
            try:
                Compose = self.auto.center(self.auto.locateOnScreen('assets/Compose.png'))
                self.auto.click(Compose)
            except:
                pass
            else:
                break
        
        sleep(randint(1, 3))

        while True:
            try:
                To = self.auto.center(self.auto.locateOnScreen('assets/To.png'))
                self.auto.click(To)
            except:
                pass
            else:
                break

        self.auto.typewrite(user,0.25)
        
        sleep(randint(0,2))
        
        self.auto.press('tab')
        self.auto.press('tab')

        sleep(randint(1,3))

        while True:
            try:
                Subject = self.auto.center(self.auto.locateOnScreen('assets/Subject.png'))
                self.auto.click(Subject)
            except:
                pass
            else:
                break

        self.auto.typewrite(subject,0.26)

        self.auto.press('tab')

        sleep(randint(1,3))

        self.auto.typewrite(message, 0.38)

        sleep(randint(1,3))

        while True:
            try:
                Send = self.auto.center(self.auto.locateOnScreen('assets/Send.png'))
                self.auto.click(Send)
            except:
                pass
            else:
                break
            
        tried = 0
        
        while tried < 4:
            try:
                Sent = self.auto.locateOnScreen('assets/Sent.png')
                _Sent = self.auto.locateOnScreen('assets/_Sent.png')

                if bool(_Sent) or bool(Sent):
                    sleep(randint(1,3))
                    return True
                else:
                    sleep(randint(0.1,1.3))
                    tried += 1
                    if tried == 3:
                        return False
            except:
                pass

    def stop(self):
        self.logged_in = False
        

                    
            
        

if __name__ == '__main__':
    Email = EmailSender()
    print('Bot has started!')
    Sent = Email.sendMessage('chuckwukareuben09@gmail.com',"Hey man, I await your response.",subject='Python Ninja')
    if Sent:
        print('message sent')
    else:
        print('message not sent')


"""
To use the API create an Instance of EmailSender()
call .sendMessage method of the instance to send an email
.sendMessage takes two compulsory and one optional parameter:
i. Email address of the receiver
ii. Message to send to the receiver
iii. Subject is optional and must be specified with the assignment operator as in <Email.sendMessage(receiver, message, subject='The Subject of the Message'>

To send message to multiple users:
loop through the list of the users and call the .sendMesasage of the Email Sender
as in :

listOfReceivers  =  ['first@gmail.com','second@yahoo.com','third@blahblah.com']

for receiver in listOfReceivers:
    Email = EmailSender()
    Sent = Email.sendMessage(receiver,<message to broadcast>,subject='Python Ninja')
    if Sent:
        print('message sent')
    else:
        print('message not sent')

Note:
i. Gmail must be opened and visible at the topmost window for EmailSender to instantiate,
ii. '.sendMessage' returns a boolean i.e True if sent and False if not,
iii. for .sendMessage to run gmail must be opened in a chrome browser and must be visible at the topmost window,
iv. The bot works as long as Gmail is opened in a chrome browser and visible at the topmost window,
v. If the bot is running and Gmail is not visible at the topmost windows it doesn't crash, but waits for it to be visible before performing the task,
vi. The assests folder consist of files that should not be tampered with.
"""
